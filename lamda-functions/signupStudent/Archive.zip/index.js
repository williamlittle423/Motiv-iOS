const { MongoClient } = require('mongodb');
const bcrypt = require('bcrypt');

exports.handler = async (event) => {
    let response = { statusCode: 200, body: 'User saved successfully' };
    try {
        const client = new MongoClient(process.env.MONGO_URI);
        await client.connect();
        const database = client.db(process.env.DATABASE_NAME);
        const users = database.collection(process.env.COLLECTION_NAME);

        // Parse the user data from the event body
        const userData = JSON.parse(event.body);

        // Encrypt the password before saving
        const saltRounds = 3; // You can adjust the salt rounds as needed
        const hashedPassword = await bcrypt.hash(userData.password, saltRounds);
        userData.password = hashedPassword; // Replace the plain password with the hashed one

        // Insert the user data into the MongoDB collection
        await users.insertOne(userData);
    } catch (error) {
        console.error("Error saving user:", error);
        response = { statusCode: 500, body: 'Error saving user' };
    }

    return response;
};
